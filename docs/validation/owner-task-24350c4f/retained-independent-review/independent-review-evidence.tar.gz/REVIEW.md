RESULT: passed

# Independent Flutter compatibility re-review

The Flutter 3.19.0 / Dart 3.3.0 compatibility finding is closed for the exact uncommitted artifact below. Flutter 3.41.7 / Dart 3.11.5 also passes the focused package and widget checks. This verdict does not accept owner task 24350c4f-985e-4762-ac15-445f69009f18, establish live runtime readiness, publish the SDK, or approve ERP adoption.

Reviewer: independent validation run `530e0cd7-ad95-4528-8570-1178e6144464`, work request `57d62709-f258-4f62-ab23-56b4e1101769`, September 11, 2026. This reviewer did not implement the repaired source. Review target: implementation work request `c8df7449-ae38-4d90-b806-1bc1f8237c1a`, run `00bb50b4-2369-4fb4-a65f-1a65ac6eafd0`.

## Authority and preservation

Handrail MCP current context confirmed the active Chat SDK project `1791fdf7-f197-483c-ba67-5c0da8f4315f`, this read-only validation request, and read-only Hitcents context. All four attached frozen memories were fetched and applied; their guidance does not expand this focused review into implementation or deployment. No source/lead worktree, original evidence, consumer pin, shared SDK source, service, identity, database, queue, or ERP change was made. No commit, push, publication, deployment, raw-listener visit, or external message occurred. No target URL was supplied or visited: live route/Vault acceptance is explicitly excluded from this focused re-review.

Disposable reconstruction, toolchains, packages, consumers, review-only test probes, logs and this report are under this report's directory. Review probes add separate files only inside disposable packages; production `lib/` and existing artifact tests were not edited. SDKs are independent writable copies, not hard links. Pub caches are separate for each SDK. Expensive checks ran sequentially with `flutter test --concurrency=2`; inherited `VITEST_MAX_WORKERS=1` was retained. Configured memory limits were disabled (`HANDRAIL_CODEX_MEMORY_LIMITS_ENABLED=0` and worker memory bounds infinity). No artificial run/time/token budget was imposed.

## Exact artifact and correspondence — PASS

Combined artifact: `248f3f7986001f99414f5a149c477177059b1dcfc0a49be7c223a6190a5fc2eb`.

| Repository | Base commit | Complete patch SHA256 | Verified source files |
| --- | --- | --- | ---: |
| Flutter | `8926839d7467860a738c5526aacb7330a5510483` | `b0f79227038952d5ba2ceb88b87f327108580009549778cd689edd4ba2edcdd7` | 471 |
| JS | `9f62a562c5235759efa4c0a05858acae755c0aff` | `3ead6aa48b22389ed8376caa113013780560ced04075f634c8c67e7ddc25c188` | 1126 |
| Preview | `52fe6563bfeb9d1289fa39bcba40cd887ee7914e` | empty patch: `e3b0c44298fc1c149afbf4c8996fb92427ae41e4649b934ca495991b7852b855` | 15 |

`reconstruct.py` independently recalculated the combined identity using the saved canonical repository records, verified each base HEAD and patch digest, extracted each base with `git archive`, and ran `git apply --check` followed by application in disposable directories. All 1,612 non-evidence source files match both saved hashes and the supplied source worktrees. The tracked/new source-file sets match the manifests, not just a selected subset. All 226 saved evidence digests match. Original evidence and source are checked again in `final-integrity.json`.

The saved `minimum-final-pass` and `current-final-pass` initial manifests plus their two-file layout overlays each match all 348 final package inputs. Fresh independent runs started from the complete final reconstruction, including `handrail_thread_view.dart` and `handrail_thread_lifecycle_cases.dart`; no earlier snapshot is substituted for the layout change. Saved implementation `results.json`, `layout-results.json`, example results, README, patch identities and toolchain provenance were inspected as supporting evidence, then checks were freshly executed. See `identity-verification.json`, `final-integrity.json`, and each independent run's `input-sha256.json`.

## Toolchains and commands

Minimum SDK was downloaded from the recorded official archive URL `https://storage.googleapis.com/flutter_infra_release/releases/stable/linux/flutter_linux_3.19.0-stable.tar.xz`. Independently calculated SHA256: `4cc1706fbd6e2a5c0ee34a6f8de875aae20904c9f47e18c88d2fcb25d9ea1a79`. Framework revision is `bae5e49bc2a867403c43b2aae2de8f8c33b037e4`, Dart 3.3.0. Initial extraction encountered the worker namespace's unsupported uid/gid ownership restoration; repeating extraction with `tar --no-same-owner` completed successfully. This was an extraction issue, not a compatibility failure.

Current SDK was independently copied from the installed read-only `/opt/handrail/.handrail/flutter-sdk` using `cp -a --no-preserve=ownership --reflink=auto`. It reports Flutter 3.41.7, framework `cc0734ac716fbb8b90f3f9db8020958b1553afa7`, Dart 3.11.5. Its Git source status is clean; its channel reports `[user-branch]` and repository URL `unknown source`, so this is explicitly verification of the installed SDK at that release revision, not a claim that a fresh official 3.41.7 archive was downloaded. Key executable/framework hashes match the installed SDK and are saved in `final-integrity.json`. Package configuration points to private SDK/package/pub-cache paths.

From this report directory, the performed high-level commands were:

```sh
python3 reconstruct.py
python3 verify.py "$PWD/toolchains/minimum/flutter" minimum "$PWD/check-min" "$PWD/artifact/handrail-sdk-chat-flutter"
python3 verify_example.py "$PWD/toolchains/minimum/flutter" minimum "$PWD/check-min" "$PWD/artifact/handrail-sdk-chat-flutter"
python3 run_probes.py minimum
python3 verify.py "$PWD/toolchains/current" current "$PWD/check-current" "$PWD/artifact/handrail-sdk-chat-flutter"
python3 verify_example.py "$PWD/toolchains/current" current "$PWD/check-current" "$PWD/artifact/handrail-sdk-chat-flutter"
python3 run_probes.py current
python3 run_diagnostics.py minimum
python3 run_diagnostics.py current
python3 finish_probes.py
python3 final_integrity.py
```

For reproduction choose new output labels/directories for `verify.py`; its outputs deliberately require unused locations. `run_probes.py`, `run_diagnostics.py`, and `finish_probes.py` contain explicit label-to-scratch mappings. Copied verification scripts were read before execution and execute the existing relevant test suites; review-only probe generators are independently authored. Logs and result JSON retain exact executable paths, arguments, working directories, exit statuses and durations. No pipeline return value is used instead of the per-check statuses (the probe runner intentionally records a failed test exit in JSON even when the Python process itself completes).

Underlying commands include clean `flutter pub get --no-example`, `dart analyze lib`, scoped `dart analyze`, `flutter test --no-pub --concurrency=2 --reporter=expanded`, clean consumer `flutter pub get`, consumer `dart analyze test`, and `flutter build web --release --no-pub`. Example validation first resolves its actual unchanged HTTPS Git pin `51bc3e1411858ce38980f5beded683dee957d1a3`, saving that lock, then uses a disposable path override to build the repaired uncommitted artifact. The source/real consumer pins remain unchanged. Both sets of package, consumer, pinned-example and artifact-example lockfiles are saved.

## Independent results

| Check | 3.19.0 / 3.3.0 | 3.41.7 / 3.11.5 | Evidence |
| --- | --- | --- | --- |
| Clean package and fresh local consumer resolution | PASS | PASS | `minimum/results.json`, `current/results.json`, resolution logs and locks |
| Entire public library analysis | PASS; 65 informational diagnostics | PASS; 66 informational diagnostics | `*/public-library-analysis.log`; exit 0, no errors/warnings |
| Scoped changed-source/test analysis | PASS | PASS | `*/scoped-analysis.log` |
| Reply/settings/composer/thread/reducer/theme regressions, complete final artifact | 314 PASS | 314 PASS | `*/regressions.log` |
| Workspace reply/named-thread/discovery navigation | 54 PASS | 54 PASS | `*/workspace-reply-navigation.log` |
| Six public imports; widget mount, actual stream update and teardown | 1 PASS | 1 PASS | `*/consumer-analysis.log`, `*/consumer-widget.log` |
| Example actual Git-pin resolution; local artifact resolution | PASS | PASS | `*/example-results.json` and saved locks |
| Example analysis and release web compilation, final layout included | PASS | PASS | `*/example-analysis.log`, `*/example-web-build.log` |
| Reviewer short-height keyboard/geometry/preservation probes plus extracted huddle selector | 7 PASS | 7 PASS | `*/reviewer-final-probes.log` and JSON |
| Same six short-height probes with real-font widget captures | 6 PASS | 6 PASS | `*/reviewer-diagnostics.log`, `*/media/` |

Existing library informational lints/deprecations are not presented as zero diagnostics. Both builds retain the example's missing Cupertino icon-font warning. The current SDK also performs a successful Wasm dry run; no independent Wasm runtime acceptance is inferred. JS and preview were reconstructed and verified unchanged; unchanged JS/Node/React validation was not repeated in this Flutter-focused request.

## Behavior and accessibility review

**Composer portal identity and preservation — PASS at widget boundary.** The stable LayoutBuilder key preserves the TextField/OverlayPortal subtree when reply and attachment rows are inserted or removed. The actual composer suite runs offline/failure, reference cancellation/retry, attachments, send, formatting, typing and input-action paths on both SDKs. It no longer triggers Flutter 3.19's duplicate portal-controller attachment. The thread restriction cases verify the same mounted composer, same retained draft, reference `reply-1`, `notifyAuthor=false`, retained attachment, and unchanged thread conversation through remote lock/archive/restore and host disable states. The independent short-height probes additionally assert these values after keyboard traversal and scrolling.

**Actual reply destination and mode distinction — PASS at HTTP-fixture boundary.** Reviewed `handrail_reply_routing_cases.dart` checks outgoing request bodies, not only the widget's conversation property. Discord channel/DM/group-DM Reply sends into the current conversation with the selected source and mention choice and creates no thread. Reply within an existing thread uses that thread's ID. Default/current Reply opens the appropriate thread from a parent, while Reply in an existing thread focuses and preserves composition without creating a nested thread or new reference. Switching style while composing preserves the existing reference/mention choice and canonical thread handle. Create/Open Thread remains distinct. Disabled/missing capabilities do not silently substitute thread creation. Successful local send assertions do not establish PostgreSQL persistence.

**Back/Escape — PASS at widget boundary.** The supported `onPopInvoked` replacement preserves the existing `canPop` and `_backPanel()` logic; the unused route result is not dropped from any business operation. The compact discovery test uses `handlePopRoute()` twice, checks return to the thread row and then channel control, and asserts the original composer/draft survives. Escape cases exercise return/cleanup after client replacement; keyboard reference activation and lifecycle menus are also covered. Real operating-system navigation and predictive-back/device behavior remain outside this widget run.

**Narrow height — PASS for Send reachability, with a documented nonblocking geometry observation.** The new body gives the keyed composer a bounded scroll view and leaves remaining height to the timeline. Original six restriction cases keep the default viewport and use `ensureVisible` to verify the full Send box is reachable without overflow. Independent probes use 360px width with 600, 450 and 350px heights in both modes, focus the input and Tab through to Send without calling `ensureVisible`, then check focus, hit testing, icon/Material bounds and preserved state. Font-loaded screenshots were inspected on both SDKs.

The initial stricter probes expected the entire 48px outer IconButton box to fit following automatic focus scrolling. Four cases per SDK failed (450/350px with the default test font): outer bottom 454/354 versus viewport 450/350. This result is retained in `reviewer-probes.log`/JSON, not discarded. Follow-up measurements show the extra 4px is outer touch padding: at 350px the painted Material button occupies y310–350, icon y318–342, while the outer box is y306–354. Send remains keyboard focused, visible and hit-testable. The same assertion on painted bounds passes with both the normal test font and real font; reviewed images show the full Send circle. Classification: low-severity clipping of outer touch padding, not an inaccessible Send control or a blocking compatibility defect. At severely constrained heights a full reference/attachment composer can consume all remaining timeline space, and upper composer controls are scrolled offscreen while Send has focus. This review does not claim a polished physical mobile-keyboard/transcript experience at all heights or text scales. Host mobile acceptance should cover that tradeoff.

**Semantics changes — PASS, meaningful assertions retained.** Settings still checks the `Discord-style` label, checked-state presence and unchecked value, mutually-exclusive-group membership, enabled-state presence/value, focusability, and tap action. It removes framework-specific selected/focus-action expectations, then actually Tabs to the radio and activates with Space, asserting an outgoing `style=discord` write. This is stronger behavioral coverage than merely loosening a semantics matcher. The composer still asserts its composer/input semantic labels and Send tooltip after settling, and its test executes the keyboard input Send action. No screen-reader/device certification is claimed.

**Material/dependency/example substitutions — PASS.** ColorScheme native members take precedence over the imported extension on current Flutter; the extension supplies surface/surfaceVariant roles on 3.19. Source and captures are consistent with that intentional fallback. `withAlpha(115)` is the stated approximately-45% 8-bit list highlight and existing formatting assertions exercise it. Runtime dependency `unorm_dart ^0.3.2` resolves on both. Development constraints and the example's broadened `web` range resolve cleanly at both exact SDK versions. The separate native example's Dart ^3.11.5 floor was not widened or misrepresented.

**Huddle dropdown substitution — PASS for the changed control; full media lifecycle UNVERIFIED.** Current Flutter maps `initialValue ?? value` to FormField.initialValue; 3.19 maps `value` to the same field, and both update state on initialValue changes. An independent probe extracts the exact final `_deviceSelector` method body, mounts it, selects a different device, changes the selected ID externally, replaces the device list, and disables the control. These operations pass on both SDKs. This establishes the changed parameter's selection/update behavior only. The previously documented descriptorUnavailable media-fixture issue was not used as a new failure attributable to this patch, and the full huddle connection/device-provider lifecycle was not accepted. Optional media parity is not elevated into a new pilot requirement.

## Inspected media and limits

All five saved owner-task widget PNGs were opened: default thread Reply, Discord thread Reply, confirmed Discord setting, failed save, and recovered save. They show visibly distinct reply controls/reference UI and clear effective-versus-unconfirmed settings messaging. The Discord thread capture displays an unavailable source fixture, so it cannot prove successful authorized source retrieval. They are fixture renders, not live app captures, and their saved evidence hashes do not alone establish final-layout visual coverage.

This reviewer additionally generated six final-artifact real-font keyboard captures per SDK, and opened the 350px and 450px Discord captures for both. The images show the retained text and attachment and fully painted Send button after keyboard scrolling. Their font-backed geometry and assertions are saved alongside default-test-font probes. They still use the existing narrow HTTP transport fixture; they prove neither a functioning backend nor live browser/mobile acceptance.

## Remaining readiness requirements and next action

No new blocking defect attributable to this compatibility repair was found. Only the false Flutter floor finding is closed. Overall owner-task readiness remains **not accepted**:

* Independent PostgreSQL16 verification remains required in a permitted isolated harness, including teardown. The unchanged prior root-UID failure was not repeated.
* Final-artifact Flutter-to-PostgreSQL and cross-client runtime acceptance, preference propagation/reload/reconnect/failure recovery, and authorized live browser/mobile/accessibility evidence remain required. No stopped-service/Vault setup or raw listener was attempted.
* Concrete read-only Hitcents ERP auth/tenant/directory/storage/realtime/UI/mobile integration mapping remains required. Absent ERP paths were not retried.
* Git publication, actual consumer pin advancement, deployment and adoption are not implied by disposable path-consumer passes.

Return this report and the essential worker-result summary to the existing accountable lead/planner for task `24350c4f-985e-4762-ac15-445f69009f18`. Next acceptance evidence is independent permitted PostgreSQL16 results, authorized final-artifact cross-client/UI results, and concrete read-only ERP mapping; retain the existing owner/controller and release gates. No duplicate task/controller or queue mutation was created by this reviewer.
