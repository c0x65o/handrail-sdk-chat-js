from pathlib import Path
import json,hashlib,shutil,tarfile
root=Path(__file__).parent; E=Path('/opt/handrail/repos/handrail/handrail-chat/handrail-sdk-chat-js/docs/validation/owner-task-24350c4f/flutter-compatibility'); binding=root/'original-binding';binding.mkdir(exist_ok=True)
for name in ['patch-identities.json','toolchain-provenance.json','evidence-sha256.json','handrail-sdk-chat-flutter-source-sha256.json','handrail-sdk-chat-js-source-sha256.json','handrail-chat-preview-flutter-source-sha256.json']:
 shutil.copy2(E/name,binding/name)
shutil.copytree(E/'patches',binding/'patches',dirs_exist_ok=True)
for label in ['minimum-final-pass','current-final-pass']:
 (binding/label).mkdir(exist_ok=True)
 for name in ['input-sha256.json','layout-input-sha256.json','results.json','layout-results.json','example-results.json','example-source-sha256.json']:
  shutil.copy2(E/label/name,binding/label/name)
summary={'result':'passed','scope':'Closes only the Flutter 3.19/Dart 3.3 compatibility finding; overall task NOT accepted','reviewer_run_id':'530e0cd7-ad95-4528-8570-1178e6144464','artifact':json.loads((E/'patch-identities.json').read_text()),'independent_results':{},'finding':{'severity':'low','description':'At 350px height, keyboard focus can clip 4px of outer Send touch padding; the painted 40px button and icon remain fully visible, focused and hit-testable. Initial full-outer-box assertions failed and are retained. Refined geometry and state probes pass on both SDKs. No blocking patch regression found.'},'coverage_limits':['HTTP/widget/component fixtures, not live app/DB/media acceptance','No fresh JS/preview checks beyond unchanged source/patch identity','PostgreSQL16 verification, final Flutter-to-PostgreSQL/cross-client runtime acceptance and concrete read-only ERP mapping remain required','No registry publication, consumer pin change, deployment or adoption'], 'report_markdown':(root/'REVIEW.md').read_text()}
for label in ['minimum','current']:
 summary['independent_results'][label]={'core':json.loads((root/label/'results.json').read_text()),'example':json.loads((root/label/'example-results.json').read_text()),'probes':json.loads((root/label/'reviewer-final-probes.json').read_text()),'real_font_diagnostics':json.loads((root/label/'reviewer-diagnostics.json').read_text()),'test_counts':{'regressions':314,'navigation':54,'public_import_consumer':1,'final_independent_probes':7,'real_font_diagnostic_reruns':6}}
(root/'WORKER_RESULT.json').write_text(json.dumps(summary,indent=2)+'\n')
files=[p for p in root.iterdir() if p.is_file() and p.suffix in ['.py','.dart','.md','.json'] and p.name!='report-sha256.json']
for name in ['minimum','current','original-binding']:
 files += [p for p in (root/name).rglob('*') if p.is_file()]
manifest={str(p.relative_to(root)):hashlib.sha256(p.read_bytes()).hexdigest() for p in sorted(files)}
(root/'report-sha256.json').write_text(json.dumps(manifest,indent=2)+'\n');files.append(root/'report-sha256.json')
with tarfile.open(root/'independent-review-evidence.tar.gz','w:gz') as tar:
 for p in sorted(files):tar.add(p,arcname=str(p.relative_to(root)),recursive=False)
print(json.dumps({'report_files':len(files),'bundle_sha256':hashlib.sha256((root/'independent-review-evidence.tar.gz').read_bytes()).hexdigest(),'bundle_bytes':(root/'independent-review-evidence.tar.gz').stat().st_size},indent=2))
