from pathlib import Path
import os,sys,subprocess,json,time
root=Path(__file__).parent; label=sys.argv[1]; scratch=root/('check-min' if label=='minimum' else 'check-current'); sdk=root/'toolchains'/('minimum/flutter' if label=='minimum' else 'current'); package=scratch/'package'; out=root/label
subprocess.run(['python3',str(root/'make_diagnostics.py'),str(package)],check=True)
env=dict(os.environ,FLUTTER_ROOT=str(sdk),PUB_CACHE=str(scratch/'pub-cache'),CI='true',FLUTTER_SUPPRESS_ANALYTICS='true',DART_SUPPRESS_ANALYTICS='true',HANDRAIL_WIDGET_EVIDENCE_DIR=str(out/'media'));env['PATH']=str(sdk/'bin')+os.pathsep+env['PATH'];env.pop('FLUTTER_ALREADY_LOCKED',None)
cmd=[str(sdk/'bin/flutter'),'test','--no-pub','--concurrency=2','--reporter=expanded','test/reviewer_diagnostic_test.dart','--name','reviewer diagnostic']
start=time.time()
with (out/'reviewer-diagnostics.log').open('w') as f:
 f.write('cwd: '+str(package)+'\ncommand: '+json.dumps(cmd)+'\n');f.flush();r=subprocess.run(cmd,cwd=package,env=env,stdout=f,stderr=subprocess.STDOUT)
(out/'reviewer-diagnostics.json').write_text(json.dumps(dict(command=cmd,cwd=str(package),exit_code=r.returncode,elapsed_seconds=time.time()-start),indent=2)+'\n');print('reviewer-diagnostics',label,r.returncode)
