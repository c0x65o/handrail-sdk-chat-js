from pathlib import Path
import sys
root=Path(__file__).parent; p=Path(sys.argv[1])/'test'
s=(root/'artifact/handrail-sdk-chat-flutter/lib/src/handrail_huddle_panel.dart').read_text(); selector=s[s.index('  Widget _deviceSelector('):s.index('  String? _selectedDeviceId(')]
probe='''import 'package:flutter/material.dart';
import 'package:flutter_test/flutter_test.dart';
import 'package:handrail_chat/ui.dart';
import 'package:handrail_chat/media.dart';
// Exact extracted selector body; proves component interaction, not huddle lifecycle.
'''+selector+'''
void main() {
 testWidgets('reviewer exact huddle selector preserves selection and device updates', (tester) async {
  var selected = 'a'; var enabled = true; var writes = 0;
  var devices = const [ChatMediaDevice(id:'a',kind:ChatMediaDeviceKind.audioInput,label:'Built in'),ChatMediaDevice(id:'b',kind:ChatMediaDeviceKind.audioInput,label:'USB')];
  late StateSetter update;
  await tester.pumpWidget(MaterialApp(home:Scaffold(body:StatefulBuilder(builder:(context,setState){
   update=setState;
   return _deviceSelector(keyName:'audio-input',label:'Microphone',devices:devices,selectedId:selected,enabled:enabled,onChanged:(id){setState((){selected=id!;writes++;});});
  }))));
  expect(find.text('Built in'),findsOneWidget);
  await tester.tap(find.byType(DropdownButtonFormField<String>)); await tester.pumpAndSettle();
  await tester.tap(find.text('USB').last); await tester.pumpAndSettle();
  expect(selected,'b'); expect(writes,1);
  update((){selected='a';}); await tester.pumpAndSettle();
  expect(tester.state<FormFieldState<String>>(find.byType(DropdownButtonFormField<String>)).value,'a');
  update((){devices=const [ChatMediaDevice(id:'c',kind:ChatMediaDeviceKind.audioInput,label:'Dock')];selected='c';});
  await tester.pumpAndSettle();
  expect(find.text('Dock'),findsOneWidget);
  expect(tester.state<FormFieldState<String>>(find.byType(DropdownButtonFormField<String>)).value,'c');
  update((){enabled=false;});await tester.pumpAndSettle();
  expect(tester.widget<DropdownButtonFormField<String>>(find.byType(DropdownButtonFormField<String>)).onChanged,isNull);
  expect(tester.takeException(),isNull);
 });
}
'''
(p/'reviewer_component_test.dart').write_text(probe)
