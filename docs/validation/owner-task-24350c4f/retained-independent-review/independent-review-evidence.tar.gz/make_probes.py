from pathlib import Path
import sys
p=Path(sys.argv[1])/'test'; source=Path(__file__).parent/'artifact/handrail-sdk-chat-flutter/test'
s=(source/'handrail_thread_view_test.dart').read_text().replace("part 'handrail_thread_lifecycle_cases.dart';","part 'reviewer_lifecycle_cases.dart';").replace("part 'handrail_thread_subscription_cases.dart';","part 'reviewer_subscription_cases.dart';")
s=s.replace('void main() {', '''void main() {
  for (final height in [600.0, 450.0, 350.0]) {
    for (final style in ReplyStyle.values) {
      testWidgets('reviewer narrow height $height $style scroll and keyboard Send', (tester) async {
        tester.view.physicalSize = Size(360, height);
        tester.view.devicePixelRatio = 1;
        addTearDown(tester.view.resetPhysicalSize);
        addTearDown(tester.view.resetDevicePixelRatio);
        final harness = _Harness(existingThread: true);
        addTearDown(() => _disposeLifecycleHarness(tester, harness));
        await _prepareLifecycle(tester, harness);
        harness.client.replyStyles.configure(ChatReplyStyleConfiguration(override: style));
        _seedLifecycleDraft(harness);
        await _mountLifecycle(tester, harness);
        expect(tester.takeException(), isNull);
        final state = tester.state<HandrailMessageComposerState>(find.byType(HandrailMessageComposer));
        final send = find.byKey(_composerSend);
        final input = tester.widget<TextField>(find.byKey(_composerInput));
        input.focusNode!.requestFocus();
        await tester.pumpAndSettle();
        bool sendFocused() {
          final element = tester.element(send);
          var found = false;
          FocusManager.instance.primaryFocus?.context?.visitAncestorElements((e) {
            found = identical(element,e); return !found;
          });
          return found;
        }
        for (var i=0;i<24 && !sendFocused();i++) {
          await tester.sendKeyEvent(LogicalKeyboardKey.tab);
          await tester.pumpAndSettle();
        }
        expect(sendFocused(), isTrue, reason:'Send is keyboard reachable');
        expect(send.hitTestable(), findsOneWidget, reason:'Focused Send must be visible without ensureVisible');
        expect(tester.getRect(send).bottom, lessThanOrEqualTo(height));
        expect(tester.getRect(send).top, greaterThanOrEqualTo(0));
        expect(tester.state(find.byType(HandrailMessageComposer)), same(state));
        expect(input.controller!.text, 'Retained Friday');
        expect(state.replyTo!.messageId, const MessageId('reply-1'));
        expect(state.replyTo!.notifyAuthor, isFalse);
        expect(find.textContaining('attachment-kept'), findsOneWidget);
        expect(tester.widget<HandrailMessageComposer>(find.byType(HandrailMessageComposer)).conversationId,_threadId);
        expect(tester.takeException(), isNull);
      });
    }
  }
''')
(p/'reviewer_thread_test.dart').write_text(s)
for kind in ['lifecycle','subscription']:
 (p/f'reviewer_{kind}_cases.dart').write_text((source/f'handrail_thread_{kind}_cases.dart').read_text().replace("part of 'handrail_thread_view_test.dart';","part of 'reviewer_thread_test.dart';"))
