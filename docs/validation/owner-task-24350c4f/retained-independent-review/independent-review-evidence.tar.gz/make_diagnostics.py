from pathlib import Path
import sys
root=Path(__file__).parent; p=Path(sys.argv[1])/'test'
s=(p/'reviewer_thread_test.dart').read_text().replace("import 'dart:async';", "import 'dart:async';\nimport 'widget_evidence.dart';")
s=s.replace('await _mountLifecycle(tester, harness);','await prepareWidgetEvidence(tester);\n        await _mountLifecycle(tester, harness);',1)
s=s.replace('    MaterialApp(\n      theme: theme,','    widgetEvidenceBoundary(MaterialApp(\n      theme: widgetEvidenceTheme ?? theme,').replace('child: Scaffold(body: child)),\n    );','child: Scaffold(body: child)),\n    ));')
s=s.replace("        expect(tester.getRect(send).bottom, lessThanOrEqualTo(height));", """
        final material = find.descendant(of:send,matching:find.byType(Material));
        final icon = find.descendant(of:send,matching:find.byType(Icon));
        print('LAYOUT height=$height style=$style outer=${tester.getRect(send)} material=${tester.getRect(material)} icon=${tester.getRect(icon)} focus=${FocusManager.instance.primaryFocus?.context?.widget.runtimeType}');
        await captureWidgetEvidence(tester, 'keyboard-$height-${style.name}.png');
        expect(tester.getRect(material).bottom,lessThanOrEqualTo(height),reason:'Painted button and focus surface visible');
        expect(tester.getRect(icon).bottom,lessThanOrEqualTo(height));
""")
s=s.replace('reviewer narrow height','reviewer diagnostic height')
(p/'reviewer_diagnostic_test.dart').write_text(s.replace("part 'reviewer_lifecycle_cases.dart';","part 'reviewer_diagnostic_lifecycle_cases.dart';").replace("part 'reviewer_subscription_cases.dart';","part 'reviewer_diagnostic_subscription_cases.dart';"))
for kind in ['lifecycle','subscription']:
 (p/f'reviewer_diagnostic_{kind}_cases.dart').write_text((p/f'reviewer_{kind}_cases.dart').read_text().replace("part of 'reviewer_thread_test.dart';","part of 'reviewer_diagnostic_test.dart';"))
