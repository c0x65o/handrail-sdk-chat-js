import pathlib,json,hashlib,subprocess,tarfile,io,shutil
R=pathlib.Path('/opt/handrail/repos/handrail/handrail-chat'); O=pathlib.Path(__file__).parent; E=R/'handrail-sdk-chat-js/docs/validation/owner-task-24350c4f/flutter-compatibility'
h=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
ids=json.loads((E/'patch-identities.json').read_text()); checks={}
assert hashlib.sha256(json.dumps(ids['repositories'],sort_keys=True).encode()).hexdigest()==ids['artifact_id']=='248f3f7986001f99414f5a149c477177059b1dcfc0a49be7c223a6190a5fc2eb'
for row in ids['repositories']:
 n=row['repository']; src=R/n; dest=O/'artifact'/n; dest.mkdir(parents=True,exist_ok=True)
 assert subprocess.check_output(['git','-C',str(src),'rev-parse','HEAD']).decode().strip()==row['base_head']
 patch=E/row['patch']; assert h(patch)==row['sha256']
 archive=subprocess.check_output(['git','-C',str(src),'archive',row['base_head']]); subprocess.run(['tar','-x','-C',str(dest)],input=archive,check=True)
 if patch.stat().st_size:
  subprocess.run(['git','apply','--check',str(patch)],cwd=dest,check=True)
  subprocess.run(['git','apply',str(patch)],cwd=dest,check=True)
 hashes=json.loads((E/(n+'-source-sha256.json')).read_text())
 for p,d in hashes.items(): assert h(dest/p)==h(src/p)==d,(n,p)
 actual=set(subprocess.check_output(['git','-C',str(src),'ls-files','--cached','--others','--exclude-standard']).decode().splitlines())
 actual={p for p in actual if not p.startswith('docs/validation/') and (src/p).is_file()}
 assert actual==set(hashes),(n,actual^set(hashes))
 checks[n]={'base':row['base_head'],'patch_sha256':h(patch),'source_files_verified':len(hashes)}
manifest=json.loads((E/'evidence-sha256.json').read_text()); bad=[p for p,d in manifest.items() if not (R/p).exists() or h(R/p)!=d]; assert not bad,bad
for label in ['minimum-final-pass','current-final-pass']:
 initial=json.loads((E/label/'input-sha256.json').read_text()); overlay=json.loads((E/label/'layout-input-sha256.json').read_text()); initial.update(overlay)
 for p,d in initial.items(): assert h(O/'artifact/handrail-sdk-chat-flutter'/p)==d,(label,p)
 checks[label]={'final_overlay_source_match':True,'files':len(initial)}
checks['evidence_files_verified']=len(manifest); checks['artifact_id']=ids['artifact_id']; (O/'identity-verification.json').write_text(json.dumps(checks,indent=2)+'\n'); print(json.dumps(checks,indent=2))
for p in ['verify.py','verify_example.py','public_import_test.dart']:shutil.copy2(E/p,O/p)
