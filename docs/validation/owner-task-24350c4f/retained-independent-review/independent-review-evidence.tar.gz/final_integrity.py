from pathlib import Path
import json,hashlib,subprocess
root=Path(__file__).parent; workspace=Path('/opt/handrail/repos/handrail/handrail-chat'); evidence=workspace/'handrail-sdk-chat-js/docs/validation/owner-task-24350c4f/flutter-compatibility'; sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest(); checks={}
for row in json.loads((evidence/'patch-identities.json').read_text())['repositories']:
 n=row['repository']; hashes=json.loads((evidence/(n+'-source-sha256.json')).read_text())
 assert all(sha(workspace/n/p)==sha(root/'artifact'/n/p)==d for p,d in hashes.items())
 checks[n]={'original_and_reconstructed_source_unchanged':True,'files':len(hashes)}
manifest=json.loads((evidence/'evidence-sha256.json').read_text());assert all(sha(workspace/p)==d for p,d in manifest.items());checks['original_evidence_unchanged']=len(manifest)
for label,folder in [('minimum','check-min'),('current','check-current')]:
 initial=json.loads((root/label/'input-sha256.json').read_text());assert all(sha(root/folder/'package'/p)==sha(root/'artifact/handrail-sdk-chat-flutter'/p)==d for p,d in initial.items())
 config=json.loads((root/folder/'package/.dart_tool/package_config.json').read_text()); resolved={p['name']:p['rootUri'] for p in config['packages'] if p['name'] in ['flutter','handrail_chat','test','unorm_dart']}
 checks[label]={'final_test_inputs_unchanged':len(initial),'resolved_paths':resolved}
 selected=['bin/cache/dart-sdk/bin/dart','bin/cache/flutter_tools.snapshot','packages/flutter/lib/src/material/dropdown.dart','packages/flutter/lib/src/material/color_scheme.dart','packages/flutter/lib/src/widgets/pop_scope.dart']
 checks[label]['toolchain_sha256']={p:sha(root/'toolchains'/('minimum/flutter' if label=='minimum' else 'current')/p) for p in selected}
 if label=='current':
  assert all(sha(Path('/opt/handrail/.handrail/flutter-sdk')/p)==d for p,d in checks[label]['toolchain_sha256'].items())
  assert (root/'toolchains/current/bin/cache/dart-sdk/bin/dart').stat().st_ino != Path('/opt/handrail/.handrail/flutter-sdk/bin/cache/dart-sdk/bin/dart').stat().st_ino
checks['minimum_download_sha256']=sha(root/'toolchains/flutter-3.19.0.tar.xz');assert checks['minimum_download_sha256']=='4cc1706fbd6e2a5c0ee34a6f8de875aae20904c9f47e18c88d2fcb25d9ea1a79'
(root/'final-integrity.json').write_text(json.dumps(checks,indent=2)+'\n');print(json.dumps(checks,indent=2))
