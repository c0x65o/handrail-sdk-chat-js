from pathlib import Path
import os,subprocess,json,time
root=Path(__file__).parent
for label,folder,tool in [('minimum','check-min','minimum/flutter'),('current','check-current','current')]:
 sdk=root/'toolchains'/tool; scratch=root/folder; package=scratch/'package'; out=root/label
 env=dict(os.environ,FLUTTER_ROOT=str(sdk),PUB_CACHE=str(scratch/'pub-cache'),CI='true',FLUTTER_SUPPRESS_ANALYTICS='true',DART_SUPPRESS_ANALYTICS='true');env['PATH']=str(sdk/'bin')+os.pathsep+env['PATH'];env.pop('FLUTTER_ALREADY_LOCKED',None);env.pop('HANDRAIL_WIDGET_EVIDENCE_DIR',None)
 # Same diagnostics with normal test font: confirms initial outer-padding finding,
 # with assertions on actual Material and icon geometry and preserved draft.
 cmd=[str(sdk/'bin/flutter'),'test','--no-pub','--concurrency=2','--reporter=expanded','test/reviewer_diagnostic_test.dart','test/reviewer_component_test.dart','--name','reviewer']
 start=time.time()
 with (out/'reviewer-final-probes.log').open('w') as f:
  f.write('cwd: '+str(package)+'\ncommand: '+json.dumps(cmd)+'\n');f.flush();r=subprocess.run(cmd,cwd=package,env=env,stdout=f,stderr=subprocess.STDOUT)
 (out/'reviewer-final-probes.json').write_text(json.dumps(dict(command=cmd,cwd=str(package),exit_code=r.returncode,elapsed_seconds=time.time()-start),indent=2)+'\n');print(label,r.returncode,flush=True)
